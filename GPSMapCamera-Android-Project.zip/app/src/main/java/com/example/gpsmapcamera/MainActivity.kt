package com.example.gpsmapcamera

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.*
import android.location.Geocoder
import android.os.*
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var viewFinder: PreviewView
    private lateinit var tvAddress: TextView
    private lateinit var tvCoords: TextView
    private lateinit var tvDateTime: TextView
    private lateinit var btnCapture: Button
    private lateinit var btnFlipCamera: Button

    private var imageCapture: ImageCapture? = null
    private var cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var currentLat: Double = 0.0
    private var currentLng: Double = 0.0
    private var currentAddress: String = "Location unavailable"

    private val bgExecutor = Executors.newSingleThreadExecutor()
    private val clockHandler = Handler(Looper.getMainLooper())

    private val requiredPermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        val locationGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true

        if (cameraGranted) startCamera() else Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
        if (locationGranted) startLocationUpdates()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewFinder = findViewById(R.id.viewFinder)
        tvAddress = findViewById(R.id.tvAddress)
        tvCoords = findViewById(R.id.tvCoords)
        tvDateTime = findViewById(R.id.tvDateTime)
        btnCapture = findViewById(R.id.btnCapture)
        btnFlipCamera = findViewById(R.id.btnFlipCamera)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        if (hasAllPermissions()) {
            startCamera()
            startLocationUpdates()
        } else {
            permissionLauncher.launch(requiredPermissions)
        }

        startLiveClock()

        btnFlipCamera.setOnClickListener {
            cameraSelector = if (cameraSelector == CameraSelector.DEFAULT_BACK_CAMERA) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }
            startCamera()
        }

        btnCapture.setOnClickListener {
            takePhotoWithGeoStamp()
        }
    }

    private fun hasAllPermissions(): Boolean = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(viewFinder.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture)
            } catch (e: Exception) {
                Toast.makeText(this, "Camera error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        val locationRequest = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 4000L)
            .setMinUpdateIntervalMillis(2000L)
            .build()

        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    val loc = result.lastLocation ?: return
                    currentLat = loc.latitude
                    currentLng = loc.longitude
                    tvCoords.text = String.format(Locale.US, "Lat: %.6f° | Long: %.6f°", currentLat, currentLng)
                    fetchAddressFromCoords(currentLat, currentLng)
                }
            },
            Looper.getMainLooper()
        )
    }

    private fun fetchAddressFromCoords(lat: Double, lng: Double) {
        bgExecutor.execute {
            try {
                val geocoder = Geocoder(this, Locale.getDefault())
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(lat, lng, 1)
                if (!addresses.isNullOrEmpty()) {
                    val addr = addresses[0].getAddressLine(0) ?: "Address not found"
                    currentAddress = addr
                    runOnUiThread { tvAddress.text = addr }
                }
            } catch (e: Exception) {
                runOnUiThread { tvAddress.text = "Offline / Address unavailable" }
            }
        }
    }

    private fun startLiveClock() {
        val runnable = object : Runnable {
            override fun run() {
                tvDateTime.text = getFormattedDateTime()
                clockHandler.postDelayed(this, 1000L)
            }
        }
        clockHandler.post(runnable)
    }

    private fun getFormattedDateTime(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, EEEE • hh:mm:ss a", Locale("en", "IN"))
        return sdf.format(Date())
    }

    private fun takePhotoWithGeoStamp() {
        val capture = imageCapture ?: return
        btnCapture.isEnabled = false

        capture.takePicture(
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val rotation = image.imageInfo.rotationDegrees
                    val rawBitmap = image.toBitmap()
                    image.close()

                    bgExecutor.execute {
                        val rotatedBitmap = rotateBitmap(
                            rawBitmap,
                            rotation,
                            cameraSelector == CameraSelector.DEFAULT_FRONT_CAMERA
                        )
                        val stampedBitmap = drawGeoStampOnBitmap(rotatedBitmap)
                        val saved = saveBitmapToGallery(stampedBitmap)

                        runOnUiThread {
                            btnCapture.isEnabled = true
                            if (saved) {
                                Toast.makeText(this@MainActivity, "Photo saved to Gallery!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this@MainActivity, "Failed to save photo", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    btnCapture.isEnabled = true
                    Toast.makeText(this@MainActivity, "Capture failed: ${exception.message}", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    private fun rotateBitmap(bitmap: Bitmap, degrees: Int, mirrorHorizontal: Boolean): Bitmap {
        val matrix = Matrix().apply {
            postRotate(degrees.toFloat())
            if (mirrorHorizontal) {
                postScale(-1f, 1f, bitmap.width / 2f, bitmap.height / 2f)
            }
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    private fun drawGeoStampOnBitmap(original: Bitmap): Bitmap {
        val result = original.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(result)

        val width = result.width.toFloat()
        val height = result.height.toFloat()
        val margin = width * 0.035f
        val padding = width * 0.03f

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#60A5FA")
            textSize = width * 0.028f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val addressPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = width * 0.032f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val metaPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E5E7EB")
            textSize = width * 0.026f
        }

        val textWidth = (width - (margin * 2) - (padding * 2)).toInt()
        val addressLayout = StaticLayout.Builder.obtain(
            currentAddress, 0, currentAddress.length, addressPaint, textWidth
        ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

        val lineSpacing = width * 0.012f
        val boxHeight = padding * 2 +
                titlePaint.textSize + lineSpacing +
                addressLayout.height + lineSpacing +
                metaPaint.textSize * 2 + lineSpacing

        val boxTop = height - margin - boxHeight
        val boxRect = RectF(margin, boxTop, width - margin, height - margin)

        // Draw dark rounded background card
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(200, 17, 24, 39)
        }
        canvas.drawRoundRect(boxRect, width * 0.025f, width * 0.025f, bgPaint)

        // Draw text inside card
        var currentY = boxTop + padding + titlePaint.textSize
        val textX = margin + padding

        canvas.drawText("📍 GPS MAP CAMERA", textX, currentY, titlePaint)

        currentY += lineSpacing
        canvas.save()
        canvas.translate(textX, currentY)
        addressLayout.draw(canvas)
        canvas.restore()

        currentY += addressLayout.height + metaPaint.textSize + lineSpacing
        val coordsText = String.format(Locale.US, "Lat: %.6f°   Long: %.6f°", currentLat, currentLng)
        canvas.drawText(coordsText, textX, currentY, metaPaint)

        currentY += metaPaint.textSize + lineSpacing
        canvas.drawText(getFormattedDateTime(), textX, currentY, metaPaint)

        return result
    }

    private fun saveBitmapToGallery(bitmap: Bitmap): Boolean {
        val filename = "GPS_IMG_${System.currentTimeMillis()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GPSMapCamera")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }

        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            contentResolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        clockHandler.removeCallbacksAndMessages(null)
        bgExecutor.shutdown()
    }
}
